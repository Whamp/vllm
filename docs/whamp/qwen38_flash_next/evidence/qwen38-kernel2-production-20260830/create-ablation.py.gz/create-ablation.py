#!/usr/bin/env python3
from __future__ import annotations

import hashlib
from pathlib import Path

SOURCE = Path("/home/will/inference/runtime/qwen38-qsa-fp8-candidate/production.yml")
TARGET = Path("/home/will/build/qwen38-kernel2-native-sm86/ablation.yml")
EXPECTED_SOURCE_SHA256 = (
    "bfd7267653464d604f92a8b27f1965467139dc8543760a53b86b844667207d17"
)


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if text.count(old) != 1:
        raise RuntimeError(f"Kernel2 ablation Compose mismatch for {label}")
    return text.replace(old, new)


source = SOURCE.read_bytes()
if hashlib.sha256(source).hexdigest() != EXPECTED_SOURCE_SHA256:
    raise RuntimeError("Kernel2 ablation source Compose SHA-256 mismatch")
text = source.decode()
text = replace_once(
    text,
    "    container_name: qwen38-qsa-fp8-candidate",
    "    container_name: qwen38-kernel2-ablation",
    "container",
)
text = replace_once(text, "    restart: unless-stopped", '    restart: "no"', "restart")
text = replace_once(text, '      - "30002:8000"', '      - "30003:8000"', "port")
text = replace_once(
    text,
    '      VLLM_QWEN4_EXP_HYPERCONNECTION_BF16_SM86: "1"',
    '      VLLM_QWEN4_EXP_HYPERCONNECTION_BF16_SM86: "0"',
    "selector flag",
)
text += "\nnetworks:\n  default:\n    external: true\n    name: qwen38-qsa-fp8-candidate_default\n"
TARGET.write_text(text)
print(hashlib.sha256(TARGET.read_bytes()).hexdigest())
