## Quality bench, thinking mixed(pack-defaults), benchlocal-cli v0.9.10, repeat = 1

Pack | Pass / Total | Score | Std | CV | p50 latency | p95 latency | Status
---|---:|---:|---:|---:|---:|---:|---
toolcall-15 (v1.0.1) | 14 / 15 | 93% | — | — | 1.59s | 6.49s | ok
instructfollow-15 (v1.0.0) | 14 / 15 | 93% | — | — | 5.61s | 25.77s | ok

TOTAL | 28 / 30 | 93% |  |  |  |  |

Equivalent to: 140/150

<details>
<summary>Raw data</summary>

```
=== benchlocal-cli --quick  (endpoint: http://127.0.0.1:30002, model: qwen3.8-flash-next-intel-autoround-w4a16, thinking=mixed(pack-defaults), 2026-08-30T15:34:03.525078Z) ===

  [1/15] TC-01 ✓ passed pass@1 (8.4s)
  [2/15] TC-02 ✓ passed pass@1 (1.7s)
  [3/15] TC-03 ✓ passed pass@1 (1.6s)
  [4/15] TC-04 ✓ passed pass@1 (1.2s)
  [5/15] TC-05 ✓ passed pass@1 (3.6s)
  [6/15] TC-06 ✓ passed pass@1 (2.6s)
  [7/15] TC-07 ✓ passed pass@1 (2.2s)
  [8/15] TC-08 ✓ passed pass@1 (1.1s)
  [9/15] TC-09 ✓ passed pass@1 (1.6s)
  [10/15] TC-10 ✓ passed pass@1 (2.0s)
  [11/15] TC-11 ✗ verifier_fail fail (1.1s)
  [12/15] TC-12 ✓ passed pass@1 (6.5s)
  [13/15] TC-13 ✓ passed pass@1 (1.2s)
  [14/15] TC-14 ✓ passed pass@1 (1.0s)
  [15/15] TC-15 ✓ passed pass@1 (1.1s)
toolcall-15 (v1.0.1) | 14 / 15 | 93% | 1.59s | ok
  [1/15] IF-01 ✗ verifier_fail fail (20.0s)
  [2/15] IF-02 ✓ passed pass@1 (4.6s)
  [3/15] IF-03 ✓ passed pass@1 (4.6s)
  [4/15] IF-04 ✓ passed pass@1 (2.6s)
  [5/15] IF-05 ✓ passed pass@1 (5.6s)
  [6/15] IF-06 ✓ passed pass@1 (4.2s)
  [7/15] IF-07 ✓ passed pass@1 (5.6s)
  [8/15] IF-08 ✓ passed pass@1 (4.8s)
  [9/15] IF-09 ✓ passed pass@1 (18.0s)
  [10/15] IF-10 ✓ passed pass@1 (26.9s)
  [11/15] IF-11 ✓ passed pass@1 (25.8s)
  [12/15] IF-12 ✓ passed pass@1 (7.5s)
  [13/15] IF-13 ✓ passed pass@1 (2.1s)
  [14/15] IF-14 ✓ passed pass@1 (4.3s)
  [15/15] IF-15 ✓ passed pass@1 (7.1s)
instructfollow-15 (v1.0.0) | 14 / 15 | 93% | 5.61s | ok

Pack | Pass / Total | Score | p50 latency | p95 latency | Status
---|---:|---:|---:|---:|---
toolcall-15 (v1.0.1) | 14 / 15 | 93% | 1.59s | 6.49s | ok
instructfollow-15 (v1.0.0) | 14 / 15 | 93% | 5.61s | 25.77s | ok

TOTAL | 28 / 30 | 93% |  |  |

Completion and extraction diagnostics:

Pack | finish_reason=length | extraction_method | extraction_issue | response_field_used
---|---:|---|---|---
toolcall-15 | 0 / 15 (0.0%) | — | — | message.content=5
instructfollow-15 | 0 / 15 (0.0%) | — | — | message.content=15

Failure breakdown:
- toolcall-15 TC-11: verifier_fail [fail] (expected 0 tool calls, got 1)
- instructfollow-15 IF-01: verifier_fail [fail] (format regex did not match)

Warnings:
- timeout scaling active: measured_decode_tps=35.5, reference_tps=100.0, scale=2.82, token-budget-multiplier=16384/1024=16.00
```

</details>
