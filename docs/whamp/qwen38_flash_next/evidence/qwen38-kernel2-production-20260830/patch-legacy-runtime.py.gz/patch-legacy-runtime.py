#!/usr/bin/env python3
from __future__ import annotations

import hashlib
from pathlib import Path

ROOT = Path("/home/will/build/qwen38-kernel2-native-sm86/image-context")
ENV_PATH = ROOT / "envs.py"
LOW_LATENCY_PATH = ROOT / "low_latency_gemm.py"

EXPECTED_ENV_SHA256 = "fb701e932ff263612d520c1447dfdbd882da3286c889c4e01735c8456c3db508"
EXPECTED_LOW_LATENCY_SHA256 = (
    "46fcbdd4567864fce21a6f18a225d461bc49a459886bd09a11bea476d14f73e6"
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if text.count(old) != 1:
        raise RuntimeError(f"Kernel2 runtime patch mismatch for {label}")
    return text.replace(old, new)


if sha256(ENV_PATH) != EXPECTED_ENV_SHA256:
    raise RuntimeError("Kernel2 runtime envs.py source SHA-256 mismatch")
if sha256(LOW_LATENCY_PATH) != EXPECTED_LOW_LATENCY_SHA256:
    raise RuntimeError("Kernel2 runtime low_latency_gemm.py source SHA-256 mismatch")

envs = ENV_PATH.read_text()
envs = replace_once(
    envs,
    "    VLLM_BATCH_INVARIANT: bool = False\n    VLLM_TRITON_USE_TD: bool | None = None",
    "    VLLM_BATCH_INVARIANT: bool = False\n"
    "    VLLM_QWEN4_EXP_HYPERCONNECTION_BF16_SM86: bool = False\n"
    "    VLLM_TRITON_USE_TD: bool | None = None",
    "env type declaration",
)
envs = replace_once(
    envs,
    '    "VLLM_BATCH_INVARIANT": lambda: bool(int(os.getenv("VLLM_BATCH_INVARIANT", "0"))),\n'
    "    # Use tensor descriptors for Q/K/V loads and output stores in the",
    '    "VLLM_BATCH_INVARIANT": lambda: bool(int(os.getenv("VLLM_BATCH_INVARIANT", "0"))),\n'
    "    # Use the exact-shape native BF16 hyperconnection GEMM on NVIDIA SM86.\n"
    '    "VLLM_QWEN4_EXP_HYPERCONNECTION_BF16_SM86": lambda: bool(\n'
    '        int(os.getenv("VLLM_QWEN4_EXP_HYPERCONNECTION_BF16_SM86", "0"))\n'
    "    ),\n"
    "    # Use tensor descriptors for Q/K/V loads and output stores in the",
    "env registry",
)
ENV_PATH.write_text(envs)

low_latency = LOW_LATENCY_PATH.read_text()
low_latency = replace_once(
    low_latency,
    "import vllm.envs as envs\n",
    "import vllm.envs as envs\nfrom vllm.logger import init_logger\n",
    "logger import",
)
low_latency = replace_once(
    low_latency,
    "from vllm.utils.torch_utils import direct_register_custom_op\n\n"
    "QWEN38NEXT_GEMM_PLANS:",
    "from vllm.utils.torch_utils import direct_register_custom_op\n\n"
    "logger = init_logger(__name__)\n\n"
    "QWEN38NEXT_GEMM_PLANS:",
    "logger definition",
)
low_latency = replace_once(
    low_latency,
    "QWEN38NEXT_GEMM_PLANS: dict[tuple[int, int], dict[int, SkinnyGemmConfig]] = {",
    "QWEN38NEXT_SM86_HYPERCONNECTION_PLANS: dict[tuple[int, int, int], "
    "tuple[int, int]] = {\n"
    "    # (M, N, K): (block threads, output rows per block)\n"
    "    (1, 336, 10240): (256, 1),\n"
    "    (2, 336, 10240): (256, 1),\n"
    "    (1, 10240, 320): (32, 4),\n"
    "}\n\n"
    "QWEN38NEXT_GEMM_PLANS: dict[tuple[int, int], dict[int, SkinnyGemmConfig]] = {",
    "SM86 plans",
)
low_latency = replace_once(
    low_latency,
    "def _is_sm103() -> bool:\n"
    "    return current_platform.is_device_capability((10, 3))\n\n\n"
    "def _is_packed_row_major(tensor: torch.Tensor) -> bool:",
    "def _is_sm103() -> bool:\n"
    "    return current_platform.is_device_capability((10, 3))\n\n\n"
    "def _is_sm86() -> bool:\n"
    "    return current_platform.is_device_capability((8, 6))\n\n\n"
    "def qwen38next_sm86_hyperconnection_plan(\n"
    "    tokens: int,\n"
    "    output_features: int,\n"
    "    input_features: int,\n"
    ") -> tuple[int, int] | None:\n"
    '    \"\"\"Return the native SM86 launch plan for an exact Qwen hyperconnection GEMM.\"\"\"\n\n'
    "    return QWEN38NEXT_SM86_HYPERCONNECTION_PLANS.get(\n"
    "        (tokens, output_features, input_features)\n"
    "    )\n\n\n"
    "def _sm86_hyperconnection_op_available() -> bool:\n"
    '    return hasattr(torch.ops._C, "qwen4_exp_hyperconnection_bf16_sm86")\n\n\n'
    "def _run_qwen38next_sm86_hyperconnection(\n"
    "    x: torch.Tensor,\n"
    "    weight: torch.Tensor,\n"
    ") -> torch.Tensor:\n"
    "    return torch.ops._C.qwen4_exp_hyperconnection_bf16_sm86(x, weight)\n\n\n"
    "def _is_packed_row_major(tensor: torch.Tensor) -> bool:",
    "SM86 helpers",
)
low_latency = replace_once(
    low_latency,
    "class Qwen38NextLowLatencyLinearMethod(\n"
    "    _Qwen38NextLowLatencyApply, UnquantizedLinearMethod\n"
    "):\n"
    "    pass\n\n\n"
    "class Qwen38NextLowLatencyEmbeddingMethod(",
    "class Qwen38NextLowLatencyLinearMethod(\n"
    "    _Qwen38NextLowLatencyApply, UnquantizedLinearMethod\n"
    "):\n"
    "    pass\n\n\n"
    "class Qwen38NextSm86HyperconnectionLinearMethod(\n"
    "    _Qwen38NextLowLatencyApply, UnquantizedLinearMethod\n"
    "):\n"
    '    \"\"\"Apply the native SM86 BF16 kernel only to exact hyperconnection shapes.\"\"\"\n\n\n'
    "class Qwen38NextLowLatencyEmbeddingMethod(",
    "SM86 linear method",
)
low_latency = replace_once(
    low_latency,
    "def _qwen38next_low_latency_gemm(x: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:\n"
    "    plan = QWEN38NEXT_GEMM_PLANS.get((weight.shape[0], weight.shape[1]))",
    "def _qwen38next_low_latency_gemm(x: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:\n"
    "    if (\n"
    "        envs.VLLM_QWEN4_EXP_HYPERCONNECTION_BF16_SM86\n"
    "        and _is_sm86()\n"
    "        and qwen38next_sm86_hyperconnection_plan(\n"
    "            x.shape[0], weight.shape[0], weight.shape[1]\n"
    "        )\n"
    "        is not None\n"
    "        and _runtime_ok(x, weight)\n"
    "    ):\n"
    "        return _run_qwen38next_sm86_hyperconnection(x, weight)\n\n"
    "    plan = QWEN38NEXT_GEMM_PLANS.get((weight.shape[0], weight.shape[1]))",
    "SM86 runtime dispatch",
)
low_latency = replace_once(
    low_latency,
    "    if (\n"
    "        config is not None\n"
    "        and _runtime_ok(x, weight)",
    "    if (\n"
    "        config is not None\n"
    "        and _is_sm103()\n"
    "        and _runtime_ok(x, weight)",
    "SM103 CuTe guard",
)
old_enable = '''def enable_qwen38next_low_latency_gemm(
    module: nn.Module,
    dtype: torch.dtype,
) -> None:
    if dtype != torch.bfloat16 or not _is_sm103():
        return
    if not shape_dynamic_skinny_gemm.is_available():
        return
'''
new_enable = '''def enable_qwen38next_low_latency_gemm(
    module: nn.Module,
    dtype: torch.dtype,
) -> None:
    if dtype != torch.bfloat16:
        return

    if envs.VLLM_QWEN4_EXP_HYPERCONNECTION_BF16_SM86 and _is_sm86():
        if not _sm86_hyperconnection_op_available():
            raise RuntimeError(
                "Qwen3.8 SM86 hyperconnection op unavailable: rebuild "
                "vllm._C_stable_libtorch with the native kernel"
            )
        supported_shapes = {
            (output_features, input_features)
            for _, output_features, input_features in (
                QWEN38NEXT_SM86_HYPERCONNECTION_PLANS
            )
        }
        enabled_linears = 0
        for child in module.modules():
            is_linear = (
                isinstance(child, LinearBase)
                and type(child.quant_method) is UnquantizedLinearMethod
            )
            if not is_linear:
                continue
            weight = getattr(child, "weight", None)
            if weight is None or weight.dim() != 2:
                continue
            if (weight.shape[0], weight.shape[1]) in supported_shapes:
                child.quant_method = Qwen38NextSm86HyperconnectionLinearMethod()
                enabled_linears += 1
        if enabled_linears == 0:
            raise RuntimeError(
                "Qwen3.8 SM86 hyperconnection selector found no eligible linears"
            )
        logger.info(
            "Enabled native SM86 BF16 hyperconnection GEMM for %d Qwen3.8 linears",
            enabled_linears,
        )
        return

    if not _is_sm103() or not shape_dynamic_skinny_gemm.is_available():
        return
'''
low_latency = replace_once(
    low_latency,
    old_enable,
    new_enable,
    "SM86 selector",
)
LOW_LATENCY_PATH.write_text(low_latency)

print(f"envs.py {sha256(ENV_PATH)}")
print(f"low_latency_gemm.py {sha256(LOW_LATENCY_PATH)}")
