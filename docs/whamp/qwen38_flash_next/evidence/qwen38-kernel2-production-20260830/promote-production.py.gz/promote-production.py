#!/usr/bin/env python3
from __future__ import annotations

import hashlib
from pathlib import Path

RUNTIME = Path("/home/will/inference/runtime/qwen38-qsa-fp8-candidate")
SOURCE = RUNTIME / "production-before-kernel2.yml"
TARGET = RUNTIME / "production.yml"
EXPECTED_SOURCE_SHA256 = (
    "a2fe74915bdc596797b6413ee3968ec87a8d8cb343cef87300f62274c3b4caed"
)


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if text.count(old) != 1:
        raise RuntimeError(f"Kernel2 production Compose mismatch for {label}")
    return text.replace(old, new)


source = SOURCE.read_bytes()
if hashlib.sha256(source).hexdigest() != EXPECTED_SOURCE_SHA256:
    raise RuntimeError("Kernel2 production source Compose SHA-256 mismatch")
text = source.decode()
text = replace_once(
    text,
    "    image: vllm/vllm-openai:qwen38-qsa-fp8-hier-ab@sha256:4b59067e269f313a78f0a698e79261230fb02e3712f42ffd54b3e9ec9be9705a",
    "    image: vllm/vllm-openai:qwen38-qsa-fp8-hier-kernel2-bf16-sm86-42b918e3@sha256:acff9d8e08096a2265b23e50f5ff0d52a3f1e95ffa91e2fb099346e274a9b735",
    "image",
)
text = replace_once(
    text,
    "      CUDA_DEVICE_ORDER: PCI_BUS_ID\n",
    "      CUDA_DEVICE_ORDER: PCI_BUS_ID\n"
    '      VLLM_QWEN4_EXP_HYPERCONNECTION_BF16_SM86: "1"\n',
    "SM86 environment",
)
text = replace_once(
    text,
    "      io.whamp.qwen38.image-digest: sha256:4b59067e269f313a78f0a698e79261230fb02e3712f42ffd54b3e9ec9be9705a",
    "      io.whamp.qwen38.image-digest: sha256:acff9d8e08096a2265b23e50f5ff0d52a3f1e95ffa91e2fb099346e274a9b735\n"
    "      io.whamp.qwen38.kernel2-revision: 42b918e36fa3bdd04e3d7bd7ad4a9c7695b9624f",
    "labels",
)
TARGET.write_text(text)
print(hashlib.sha256(TARGET.read_bytes()).hexdigest())
