import json
import statistics
from pathlib import Path
from types import SimpleNamespace

import torch
import torch.nn.functional as F
from safetensors import safe_open

from vllm.config import VllmConfig, set_current_vllm_config
from vllm.model_executor.kernels.linear import init_int8_linear_kernel

MODEL = Path('/model')
INDEX = MODEL / 'model.safetensors.index.json'
MAX_NRMSE = 0.02
MIN_COSINE = 0.9999
MIN_SPEED_RATIO = 0.90


def load_weights():
    index = json.loads(INDEX.read_text())
    base = 'model.language_model.layers.0.attn_hyper_connection.'
    names = {
        'down': base + 'input_mix_weight_down.weight',
        'inject': base + 'block_inject_weight.weight',
        'up': base + 'input_mix_weight_up.weight',
    }
    shards = {index['weight_map'][name] for name in names.values()}
    assert len(shards) == 1
    with safe_open(MODEL / next(iter(shards)), framework='pt', device='cpu') as src:
        tensors = {kind: src.get_tensor(name) for kind, name in names.items()}
    logical_rows = tensors['down'].shape[0] + tensors['inject'].shape[0]
    pad_rows = (-logical_rows) % 16
    merged = torch.cat((tensors['down'], tensors['inject'], torch.zeros((pad_rows, tensors['down'].shape[1]), dtype=tensors['down'].dtype)))
    return {'merged_down': merged, 'up': tensors['up']}


def make_int8(weight, name):
    scale = weight.float().abs().amax(dim=1, keepdim=True).clamp_min(1e-12) / 127
    quantized = (weight.float() / scale).round().clamp(-127, 127).to(torch.int8)
    with set_current_vllm_config(VllmConfig()):
        kernel = init_int8_linear_kernel(
            is_channelwise=True,
            is_static_input_scheme=False,
            input_symmetric=True,
            module_name=f'Qwen4ExpHyperconnectionInt8Gate.{name}',
        )
    layer = torch.nn.Module()
    layer.logical_widths = [weight.shape[0]]
    layer.register_parameter('weight', torch.nn.Parameter(quantized.cuda(), requires_grad=False))
    layer.register_parameter('weight_scale', torch.nn.Parameter(scale.cuda(), requires_grad=False))
    layer.register_parameter('input_scale', None)
    layer.register_parameter('input_zero_point', None)
    layer.register_parameter('azp_adj', None)
    kernel.process_weights_after_loading(layer)
    return kernel, layer


def metrics(reference, candidate):
    r = reference.float().reshape(-1)
    c = candidate.float().reshape(-1)
    e = c - r
    return {
        'normalized_rmse': float(torch.linalg.vector_norm(e) / torch.linalg.vector_norm(r)),
        'cosine_similarity': float(F.cosine_similarity(r.view(1, -1), c.view(1, -1))),
        'maximum_absolute_error': float(e.abs().amax()),
    }


def time_op(op, iterations, repeats=5):
    for _ in range(20): op()
    torch.cuda.synchronize()
    samples=[]
    for _ in range(repeats):
        start=torch.cuda.Event(enable_timing=True); end=torch.cuda.Event(enable_timing=True)
        start.record()
        for _ in range(iterations): op()
        end.record(); end.synchronize()
        samples.append(start.elapsed_time(end)*1000/iterations)
    return {'median_microseconds': statistics.median(samples), 'samples': samples}


def graph_gate(kernel, layer, k):
    x=torch.randn((2,k),device='cuda',dtype=torch.bfloat16)
    stream=torch.cuda.Stream()
    with torch.cuda.stream(stream):
        for _ in range(3): kernel.apply_weights(layer,x)
    stream.synchronize()
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph): out=kernel.apply_weights(layer,x)
    value=torch.randn_like(x); x.copy_(value); graph.replay(); first=out.clone()
    x.copy_(value); graph.replay(); second=out.clone()
    return {'bitwise_equal': bool(torch.equal(first,second)), 'finite': bool(torch.isfinite(first).all())}


def main():
    assert torch.cuda.is_available()
    assert torch.cuda.get_device_capability()==(8,6)
    torch.manual_seed(20260829)
    results={'schema_version':1,'device_name':torch.cuda.get_device_name(),'compute_capability':list(torch.cuda.get_device_capability()),'acceptance':{'maximum_normalized_rmse':MAX_NRMSE,'minimum_cosine_similarity':MIN_COSINE,'minimum_int8_to_bf16_speed_ratio':MIN_SPEED_RATIO},'matrices':{}}
    for name, cpu_weight in load_weights().items():
        weight=cpu_weight.cuda(); kernel,layer=make_int8(cpu_weight,name)
        matrix={'logical_shape':list(cpu_weight.shape),'kernel':type(kernel).__name__,'weight_bytes':layer.weight.nbytes,'scale_bytes':layer.weight_scale.nbytes,'bf16_weight_bytes':cpu_weight.nbytes,'shapes':{},'cuda_graph':graph_gate(kernel,layer,cpu_weight.shape[1])}
        for m in (1,2,256):
            x=torch.randn((m,cpu_weight.shape[1]),device='cuda',dtype=torch.bfloat16)
            reference=F.linear(x,weight); candidate=kernel.apply_weights(layer,x)
            result=metrics(reference,candidate)
            iterations=1000 if m<=2 else 100
            bt=time_op(lambda x=x,w=weight:F.linear(x,w),iterations)
            it=time_op(lambda x=x,k=kernel,l=layer:k.apply_weights(l,x),iterations)
            result.update({'bf16_timing':bt,'int8_timing':it,'speed_ratio':bt['median_microseconds']/it['median_microseconds']})
            matrix['shapes'][str(m)]=result
        results['matrices'][name]=matrix
    results['numerical_gate_passed']=all(s['normalized_rmse']<=MAX_NRMSE and s['cosine_similarity']>=MIN_COSINE for m in results['matrices'].values() for s in m['shapes'].values())
    results['graph_gate_passed']=all(all(m['cuda_graph'].values()) for m in results['matrices'].values())
    results['performance_gate_passed']=all(s['speed_ratio']>=MIN_SPEED_RATIO for m in results['matrices'].values() for s in m['shapes'].values())
    print(json.dumps(results,sort_keys=True,indent=2))

if __name__=='__main__': main()
