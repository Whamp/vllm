# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

import hashlib
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import torch
from safetensors import safe_open

MODEL = Path('/model')
INDEX = MODEL / 'model.safetensors.index.json'
INT8_MAX = 127.0
GROUP = 128


torch.set_num_threads(2)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def quantize_per_row(weight: torch.Tensor) -> torch.Tensor:
    scales = (weight.float().abs().amax(dim=1, keepdim=True) / INT8_MAX)
    scales = scales.clamp_min(1e-8).to(torch.float16).float()
    codes = (weight.float() / scales).round().clamp(-127, 127)
    return codes * scales


def quantize_per_row_kgroup(weight: torch.Tensor) -> torch.Tensor:
    rows, columns = weight.shape
    padded_columns = math.ceil(columns / GROUP) * GROUP
    padded = torch.zeros((rows, padded_columns), dtype=torch.float32)
    padded[:, :columns] = weight.float()
    blocks = padded.view(rows, padded_columns // GROUP, GROUP)
    scales = (blocks.abs().amax(dim=2, keepdim=True) / INT8_MAX)
    scales = scales.clamp_min(1e-8).to(torch.float16).float()
    codes = (blocks / scales).round().clamp(-127, 127)
    return (codes * scales).view(rows, padded_columns)[:, :columns]


def quantize_block_128x128(weight: torch.Tensor) -> torch.Tensor:
    rows, columns = weight.shape
    padded_rows = math.ceil(rows / GROUP) * GROUP
    padded_columns = math.ceil(columns / GROUP) * GROUP
    padded = torch.zeros((padded_rows, padded_columns), dtype=torch.float32)
    padded[:rows, :columns] = weight.float()
    blocks = padded.view(
        padded_rows // GROUP,
        GROUP,
        padded_columns // GROUP,
        GROUP,
    )
    scales = (blocks.abs().amax(dim=(1, 3), keepdim=True) / INT8_MAX)
    scales = scales.clamp_min(1e-8).to(torch.float16).float()
    codes = (blocks / scales).round().clamp(-127, 127)
    return (codes * scales).view(padded_rows, padded_columns)[:rows, :columns]


def metrics(reference: torch.Tensor, reconstructed: torch.Tensor) -> dict:
    reference = reference.float().reshape(-1)
    reconstructed = reconstructed.float().reshape(-1)
    error = reconstructed - reference
    reference_squared = torch.dot(reference, reference).item()
    error_squared = torch.dot(error, error).item()
    dot = torch.dot(reference, reconstructed).item()
    reconstructed_squared = torch.dot(reconstructed, reconstructed).item()
    return {
        'element_count': reference.numel(),
        'reference_squared_sum': reference_squared,
        'error_squared_sum': error_squared,
        'dot_sum': dot,
        'reconstructed_squared_sum': reconstructed_squared,
        'normalized_rmse': math.sqrt(error_squared / reference_squared),
        'cosine_similarity': dot / math.sqrt(reference_squared * reconstructed_squared),
        'maximum_absolute_error': error.abs().amax().item(),
    }


def aggregate(rows: list[dict]) -> dict:
    totals = defaultdict(float)
    for row in rows:
        for key in (
            'element_count',
            'reference_squared_sum',
            'error_squared_sum',
            'dot_sum',
            'reconstructed_squared_sum',
        ):
            totals[key] += row[key]
    return {
        'element_count': int(totals['element_count']),
        'normalized_rmse': math.sqrt(
            totals['error_squared_sum'] / totals['reference_squared_sum']
        ),
        'cosine_similarity': totals['dot_sum']
        / math.sqrt(
            totals['reference_squared_sum']
            * totals['reconstructed_squared_sum']
        ),
        'maximum_tensor_normalized_rmse': max(row['normalized_rmse'] for row in rows),
        'minimum_tensor_cosine_similarity': min(row['cosine_similarity'] for row in rows),
        'maximum_absolute_error': max(row['maximum_absolute_error'] for row in rows),
    }


def storage_bytes(rows: int, columns: int, scheme: str) -> tuple[int, int]:
    if scheme == 'per_row':
        return rows * columns, rows * 2
    padded_columns = math.ceil(columns / GROUP) * GROUP
    if scheme == 'per_row_kgroup128':
        return rows * padded_columns, rows * (padded_columns // GROUP) * 2
    if scheme == 'block_128x128':
        return (
            rows * padded_columns,
            math.ceil(rows / GROUP) * (padded_columns // GROUP) * 2,
        )
    raise ValueError(f'Unknown scheme: {scheme}')


index = json.loads(INDEX.read_text())
suffixes = {
    'input_mix_weight_down.weight': 'down',
    'block_inject_weight.weight': 'inject',
    'input_mix_weight_up.weight': 'up',
}
groups: dict[str, dict] = defaultdict(dict)
for name, shard in index['weight_map'].items():
    for suffix, kind in suffixes.items():
        marker = '.' + suffix
        if name.endswith(marker) and 'hyper_connection' in name:
            groups[name[: -len(marker)]][kind] = (name, shard)
            break
if len(groups) != 97:
    raise RuntimeError(f'Expected 97 hyperconnection groups, found {len(groups)}')

scheme_functions = {
    'per_row': quantize_per_row,
    'per_row_kgroup128': quantize_per_row_kgroup,
    'block_128x128': quantize_block_128x128,
}
metric_rows: list[dict] = []
storage = {name: {'weight_bytes': 0, 'scale_bytes': 0} for name in scheme_functions}
logical_bf16_bytes = 0
component_count = 0

for group_index, (prefix, tensors) in enumerate(sorted(groups.items()), start=1):
    expected = {'down', 'up'} if 'inject' not in tensors else {'down', 'inject', 'up'}
    if set(tensors) != expected:
        raise RuntimeError(f'Unexpected tensors for {prefix}: {sorted(tensors)}')
    shards = {shard for _, shard in tensors.values()}
    if len(shards) != 1:
        raise RuntimeError(f'Hyperconnection group crosses shards: {prefix}')
    with safe_open(MODEL / next(iter(shards)), framework='pt', device='cpu') as source:
        loaded = {
            kind: source.get_tensor(name)
            for kind, (name, _) in tensors.items()
        }
    for kind, weight in loaded.items():
        component_count += 1
        logical_bf16_bytes += weight.numel() * weight.element_size()
        for scheme, quantize in scheme_functions.items():
            reconstructed = quantize(weight)
            row = metrics(weight, reconstructed)
            row.update({'group': prefix, 'component': kind, 'scheme': scheme})
            metric_rows.append(row)
            weight_bytes, scale_bytes = storage_bytes(*weight.shape, scheme)
            storage[scheme]['weight_bytes'] += weight_bytes
            storage[scheme]['scale_bytes'] += scale_bytes
            del reconstructed
    del loaded
    if group_index % 10 == 0:
        print(f'processed_groups={group_index}', file=sys.stderr, flush=True)

registered_bytes = 1_304_842_240
unchanged_bytes = registered_bytes - logical_bf16_bytes
for scheme, values in storage.items():
    values['candidate_registered_bytes_per_rank'] = (
        unchanged_bytes + values['weight_bytes'] + values['scale_bytes']
    )
    values['registered_bytes_saved_per_rank'] = (
        registered_bytes - values['candidate_registered_bytes_per_rank']
    )

summary = {
    'schema_version': 1,
    'model_index_sha256': sha256(INDEX),
    'model_index_tensor_count': len(index['weight_map']),
    'hyperconnection_group_count': len(groups),
    'matrix_component_count': component_count,
    'quantization': {
        'weight_codes': 'symmetric signed INT8',
        'int8_max': INT8_MAX,
        'scale_dtype': 'FP16',
        'group_size': GROUP,
        'component_scales_are_separate': True,
    },
    'schemes': {
        scheme: aggregate([row for row in metric_rows if row['scheme'] == scheme])
        for scheme in scheme_functions
    },
    'storage': {
        'current_registered_bytes_per_rank': registered_bytes,
        'current_logical_bf16_matrix_bytes_per_rank': logical_bf16_bytes,
        'unchanged_bytes_per_rank': unchanged_bytes,
        'candidates': storage,
    },
    'tensor_metrics': metric_rows,
}
json.dump(summary, sys.stdout, indent=2, sort_keys=True)
print()
