## Quality bench, thinking off, benchlocal-cli v0.9.10, repeat = 1

Pack | Pass / Total | Score | Std | CV | p50 latency | p95 latency | Status
---|---:|---:|---:|---:|---:|---:|---
toolcall-15 (v1.0.1) | 12 / 15 | 80% | — | — | 1.44s | 3.08s | ok
instructfollow-15 (v1.0.0) | 14 / 15 | 93% | — | — | 0.93s | 1.45s | ok

TOTAL | 26 / 30 | 87% |  |  |  |  |

Equivalent to: 130/150

<details>
<summary>Raw data</summary>

```
=== benchlocal-cli --quick  (endpoint: http://127.0.0.1:30003, model: qwen3.8-flash-next-intel-autoround-w4a16, thinking=off, 2026-08-30T00:17:29.307461Z) ===

  [1/15] TC-01 ✓ passed pass@1 (3.1s)
  [2/15] TC-02 ✓ passed pass@1 (1.6s)
  [3/15] TC-03 ✓ passed pass@1 (1.4s)
  [4/15] TC-04 ✓ passed pass@1 (1.2s)
  [5/15] TC-05 ✗ verifier_fail fail (1.8s)
  [6/15] TC-06 ✓ passed pass@1 (2.6s)
  [7/15] TC-07 ✓ passed pass@1 (2.0s)
  [8/15] TC-08 ✓ passed pass@1 (1.1s)
  [9/15] TC-09 ✗ verifier_fail fail (1.0s)
  [10/15] TC-10 ✓ passed pass@1 (2.0s)
  [11/15] TC-11 ✗ verifier_fail fail (1.0s)
  [12/15] TC-12 ✓ passed pass@1 (6.0s)
  [13/15] TC-13 ✓ passed pass@1 (1.2s)
  [14/15] TC-14 ✓ passed pass@1 (1.0s)
  [15/15] TC-15 ✓ passed pass@1 (1.1s)
toolcall-15 (v1.0.1) | 12 / 15 | 80% | 1.44s | ok
  [1/15] IF-01 ✓ passed pass@1 (1.1s)
  [2/15] IF-02 ✓ passed pass@1 (0.7s)
  [3/15] IF-03 ✓ passed pass@1 (0.7s)
  [4/15] IF-04 ✓ passed pass@1 (0.9s)
  [5/15] IF-05 ✓ passed pass@1 (1.2s)
  [6/15] IF-06 ✓ passed pass@1 (0.9s)
  [7/15] IF-07 ✓ passed pass@1 (1.0s)
  [8/15] IF-08 ✓ passed pass@1 (0.9s)
  [9/15] IF-09 ✓ passed pass@1 (1.2s)
  [10/15] IF-10 ✗ verifier_fail fail (1.5s)
  [11/15] IF-11 ✓ passed pass@1 (1.7s)
  [12/15] IF-12 ✓ passed pass@1 (1.0s)
  [13/15] IF-13 ✓ passed pass@1 (0.7s)
  [14/15] IF-14 ✓ passed pass@1 (0.8s)
  [15/15] IF-15 ✓ passed pass@1 (0.7s)
instructfollow-15 (v1.0.0) | 14 / 15 | 93% | 0.93s | ok

Pack | Pass / Total | Score | Δ (vs prev) | p50 latency | p95 latency | Status
---|---:|---:|---|---:|---:|---
toolcall-15 (v1.0.1) | 12 / 15 | 80% | ⚠ 1 regr / 1 fix | 1.44s | 3.08s | ok
instructfollow-15 (v1.0.0) | 14 / 15 | 93% | ⚠ 1 regr / 1 fix | 0.93s | 1.45s | ok

TOTAL | 26 / 30 | 87% | ⚠ 2 regressions, 2 fixes |  |  |

Completion and extraction diagnostics:

Pack | finish_reason=length | extraction_method | extraction_issue | response_field_used
---|---:|---|---|---
toolcall-15 | 0 / 15 (0.0%) | — | — | message.content=5
instructfollow-15 | 0 / 15 (0.0%) | — | — | message.content=15

Failure breakdown:
- toolcall-15 TC-05: verifier_fail [fail] (expected first tool create_calendar_event, got ['calculator'])
- toolcall-15 TC-09: verifier_fail [fail] (expected 2 tool calls, got 1)
- toolcall-15 TC-11: verifier_fail [fail] (expected 0 tool calls, got 1)
- instructfollow-15 IF-10: verifier_fail [fail] (word count mismatch)

Warnings:
- timeout scaling active: measured_decode_tps=50.0, reference_tps=100.0, scale=2.00
```

</details>
