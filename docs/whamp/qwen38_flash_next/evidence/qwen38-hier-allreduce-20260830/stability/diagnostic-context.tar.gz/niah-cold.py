#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0

import importlib.util
import json
import time
from pathlib import Path

acceptance_path = Path(
    "/home/will/inference/runtime/qwen38-qsa-fp8-candidate/acceptance.py"
)
spec = importlib.util.spec_from_file_location("qwen_acceptance", acceptance_path)
if spec is None or spec.loader is None:
    raise RuntimeError(f"Cannot load {acceptance_path}")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

endpoint = "http://127.0.0.1:30003"
model = "qwen3.8-flash-next-intel-autoround-w4a16"
needle = "CERULEAN COMET 8412"
target_tokens = 261500


def make_prompt(line_count: int) -> str:
    insertion = line_count * 9 // 10
    lines = ["COLD-LONG-CONTEXT-NONCE-20260830-ALLOCATOR-FINAL"]
    for index in range(line_count):
        if index == insertion:
            lines.append(f"The unique hidden phrase is {needle}.")
        lines.append(
            f"Cold ledger row {index}: stable systems preserve invariants through recovery."
        )
    lines.append("Return only the exact unique hidden phrase, without explanation.")
    return "\n".join(lines)


low, high = 1, 20000
while low < high:
    midpoint = (low + high + 1) // 2
    prompt = make_prompt(midpoint)
    count = module.request_json(
        endpoint, "/tokenize", {"model": model, "prompt": prompt}
    )["count"]
    if count <= target_tokens:
        low = midpoint
    else:
        high = midpoint - 1
prompt = make_prompt(low)
token_count = module.request_json(
    endpoint, "/tokenize", {"model": model, "prompt": prompt}
)["count"]
start = time.perf_counter()
response = module.request_json(
    endpoint,
    "/v1/chat/completions",
    {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "max_tokens": 256,
    },
)
elapsed = time.perf_counter() - start
content = (response["choices"][0]["message"].get("content") or "").strip()
if needle not in content:
    raise RuntimeError(f"Cold NIAH failed at {token_count} tokens: {response}")
result = {
    "target_tokens": target_tokens,
    "tokenized_prompt_tokens": token_count,
    "api_prompt_tokens": response["usage"]["prompt_tokens"],
    "wall_seconds": elapsed,
    "answer": content,
    "finish_reason": response["choices"][0]["finish_reason"],
    "prefix_cache_buster": "first-prompt-block",
}
output = Path(
    "/home/will/inference/runtime/qwen38-hier-allocator-diag/niah-cold.json"
)
output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps(result, indent=2, sort_keys=True))
