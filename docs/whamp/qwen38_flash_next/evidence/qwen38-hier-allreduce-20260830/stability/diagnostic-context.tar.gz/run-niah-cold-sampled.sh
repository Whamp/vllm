#!/usr/bin/env bash
set -euo pipefail
D=/home/will/inference/runtime/qwen38-hier-allocator-diag
rm -f "$D/nvml-timeseries.csv" "$D/process-swap-timeseries.csv"
printf 'timestamp,index,memory_used_mib,memory_free_mib,utilization_gpu_pct,power_w,sm_clock_mhz\n' > "$D/nvml-timeseries.csv"
printf 'timestamp,pid,name,vmswap_kib\n' > "$D/process-swap-timeseries.csv"
nohup "$D/sample-until-killed.sh" >"$D/sampler.log" 2>&1 &
sampler_pid=$!
cleanup() {
  kill "$sampler_pid" 2>/dev/null || true
  wait "$sampler_pid" 2>/dev/null || true
}
trap cleanup EXIT
for _ in $(seq 1 20); do
  if [[ $(wc -l < "$D/nvml-timeseries.csv") -gt 1 ]]; then
    break
  fi
  sleep 1
done
[[ $(wc -l < "$D/nvml-timeseries.csv") -gt 1 ]]
date -u +%FT%TZ > "$D/niah-cold-start.txt"
python3 "$D/niah-cold.py" | tee "$D/niah-cold.log"
date -u +%FT%TZ > "$D/niah-cold-end.txt"
