#!/usr/bin/env bash
set -euo pipefail
DIAG_DIR=/home/will/inference/runtime/qwen38-hier-allocator-diag
PROD_DIR=/home/will/inference/runtime/qwen38-qsa-fp8-candidate
RESTORE_UNIT=qwen38-hier-allocator-restore
curl -fsS http://127.0.0.1:30002/health >/dev/null
test "$(docker inspect -f '{{.Image}}' qwen38-qsa-fp8-candidate)" = sha256:4b59067e269f313a78f0a698e79261230fb02e3712f42ffd54b3e9ec9be9705a
test "$(docker inspect -f '{{.RestartCount}}' qwen38-qsa-fp8-candidate)" = 0
test -z "$(swapon --show --noheadings)"
systemctl is-active --quiet gpu-power-limit.service
rm -rf "$DIAG_DIR/reports"
mkdir -p "$DIAG_DIR/reports"
systemd-run --unit="$RESTORE_UNIT" --on-active=2h "$DIAG_DIR/restore-production.sh" >/dev/null
docker compose --profile qwen38-flash-next -p qwen38-qsa-fp8-candidate -f "$PROD_DIR/production.yml" stop qwen38-flash-next
sudo swapoff -a
sudo sysctl -w vm.overcommit_memory=1 >/dev/null
docker compose --profile qwen38-flash-next -p qwen38-qsa-fp8-hier-diagnostics -f "$DIAG_DIR/diagnostic.yml" up -d qwen38-flash-next
for _ in $(seq 1 360); do
  if curl -fsS --max-time 5 http://127.0.0.1:30003/health >/dev/null 2>&1; then
    break
  fi
  sleep 10
done
curl -fsS --max-time 10 http://127.0.0.1:30003/health >/dev/null
sudo sysctl -w vm.overcommit_memory=0 >/dev/null
test "$(docker inspect -f '{{.Image}}' qwen38-qsa-fp8-hier-diagnostics)" = sha256:63ccf7ea4983d950b739b1e9bc2a5fcbaba1a8537ccfbc5b7fecfa1747db6c85
test "$(docker inspect -f '{{.HostConfig.RestartPolicy.Name}}' qwen38-qsa-fp8-hier-diagnostics)" = no
test "$(docker inspect -f '{{.RestartCount}}' qwen38-qsa-fp8-hier-diagnostics)" = 0
test -z "$(swapon --show --noheadings)"
