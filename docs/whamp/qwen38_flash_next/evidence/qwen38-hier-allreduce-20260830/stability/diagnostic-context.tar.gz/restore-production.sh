#!/usr/bin/env bash
set -euo pipefail
DIAG_DIR=/home/will/inference/runtime/qwen38-hier-allocator-diag
PROD_DIR=/home/will/inference/runtime/qwen38-qsa-fp8-candidate
sudo sysctl -w vm.overcommit_memory=1 >/dev/null
docker compose --profile qwen38-flash-next -p qwen38-qsa-fp8-hier-diagnostics -f "$DIAG_DIR/diagnostic.yml" down --remove-orphans || true
docker compose --profile qwen38-flash-next -p qwen38-qsa-fp8-candidate -f "$PROD_DIR/production.yml" up -d qwen38-flash-next
for _ in $(seq 1 360); do
  if curl -fsS --max-time 5 http://127.0.0.1:30002/health >/dev/null 2>&1; then
    break
  fi
  sleep 10
done
curl -fsS --max-time 10 http://127.0.0.1:30002/health >/dev/null
sudo sysctl -w vm.overcommit_memory=0 >/dev/null
test "$(docker inspect -f '{{.Image}}' qwen38-qsa-fp8-candidate)" = sha256:4b59067e269f313a78f0a698e79261230fb02e3712f42ffd54b3e9ec9be9705a
test "$(docker inspect -f '{{.HostConfig.RestartPolicy.Name}}' qwen38-qsa-fp8-candidate)" = unless-stopped
test "$(docker inspect -f '{{.RestartCount}}' qwen38-qsa-fp8-candidate)" = 0
test "$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{end}}' qwen38-qsa-fp8-candidate)" = healthy
curl -fsS http://127.0.0.1:30002/v1/models | grep -q qwen3.8-flash-next-intel-autoround-w4a16
test -z "$(swapon --show --noheadings)"
if grep -qE '^[^ ]+ +[^ ]+ +swap +' /proc/mounts; then
  exit 1
fi
systemctl is-active --quiet gpu-power-limit.service
