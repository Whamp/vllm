#!/usr/bin/env bash
set -u
D=/home/will/inference/runtime/qwen38-hier-allocator-diag
while true; do
  nvidia-smi \
    --query-gpu=timestamp,index,memory.used,memory.free,utilization.gpu,power.draw,clocks.sm \
    --format=csv,noheader,nounits >> "$D/nvml-timeseries.csv"
  ts=$(date -u +%FT%TZ)
  docker top qwen38-qsa-fp8-hier-diagnostics -eo pid,comm 2>/dev/null \
    | tail -n +2 \
    | while read -r pid name; do
        swap=$(awk '/^VmSwap:/{print $2}' "/proc/$pid/status" 2>/dev/null || echo 0)
        printf '%s,%s,%s,%s\n' "$ts" "$pid" "$name" "${swap:-0}"
      done >> "$D/process-swap-timeseries.csv"
  sleep 1
done
