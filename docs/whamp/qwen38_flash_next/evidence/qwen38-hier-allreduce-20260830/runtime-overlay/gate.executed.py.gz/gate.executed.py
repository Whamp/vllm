# SPDX-License-Identifier: Apache-2.0
import json, os, statistics, time
import torch
import torch.distributed as dist
from vllm.distributed.device_communicators.hier_all_reduce import HierarchicalAllReduce

rank=int(os.environ['RANK']); local_rank=int(os.environ['LOCAL_RANK']); world=int(os.environ['WORLD_SIZE'])
assert world==4
torch.cuda.set_device(local_rank)
dist.init_process_group('gloo')
nccl=dist.new_group(ranks=list(range(world)), backend='nccl')
device=torch.device(f'cuda:{local_rank}')
comm=HierarchicalAllReduce(dist.group.WORLD,device,[[0,1],[2,3]])
sizes=[2560,4096,10240,65536,262144]
rows=[]
for n in sizes:
    torch.manual_seed(9000+rank+n)
    x=torch.randn(n,device=device,dtype=torch.bfloat16)
    ref=x.clone(); dist.all_reduce(ref,group=nccl); torch.cuda.synchronize()
    for _ in range(4): y=comm.all_reduce(x); torch.cuda.synchronize()
    torch.testing.assert_close(y,ref,atol=2e-2,rtol=2e-2)
    # Two graph replays exercise alternating sequence-token buffers.
    y_graph=torch.empty_like(x)
    g=torch.cuda.CUDAGraph()
    dist.barrier()
    with torch.cuda.graph(g): comm.all_reduce(x,y_graph)
    g.replay(); g.replay(); torch.cuda.synchronize()
    torch.testing.assert_close(y_graph,ref,atol=2e-2,rtol=2e-2)
    def measure(fn,iters=80):
        vals=[]
        for _ in range(10): fn(); torch.cuda.synchronize()
        dist.barrier()
        for _ in range(iters):
            start=torch.cuda.Event(enable_timing=True); end=torch.cuda.Event(enable_timing=True)
            start.record(); fn(); end.record(); end.synchronize(); vals.append(start.elapsed_time(end)*1000.0)
        return statistics.median(vals)
    hier_us=measure(lambda: comm.all_reduce(x))
    ref_out=torch.empty_like(x)
    def nccl_call():
        ref_out.copy_(x); dist.all_reduce(ref_out,group=nccl)
    nccl_us=measure(nccl_call)
    row={'rank':rank,'numel':n,'hier_us':hier_us,'nccl_us':nccl_us,'ratio':hier_us/nccl_us}
    gathered=[None]*world; dist.all_gather_object(gathered,row)
    if rank==0:
        rows.append({'numel':n,'ranks':gathered,'max_hier_us':max(z['hier_us'] for z in gathered),'max_nccl_us':max(z['nccl_us'] for z in gathered),'max_ratio':max(z['ratio'] for z in gathered)})
if rank==0:
    result={'schema_version':1,'world_size':world,'islands':[[0,1],[2,3]],'numerical':'pass','cuda_graph':'pass','rows':rows}
    path='/output/hier-gate.json'; open(path+'.tmp','w').write(json.dumps(result,indent=2,sort_keys=True)+'\n'); os.replace(path+'.tmp',path)
    print(json.dumps(result,indent=2,sort_keys=True))
dist.destroy_process_group(nccl); dist.destroy_process_group()
