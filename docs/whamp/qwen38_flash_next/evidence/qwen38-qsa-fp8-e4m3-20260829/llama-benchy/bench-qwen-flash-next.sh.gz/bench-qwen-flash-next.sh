#!/usr/bin/env bash
# Fast agentic bench (agentic-quick operating point) for qwen3.8-flash-next-ud-q4-k-xl
# on server60, at concurrency 1 and 2.
# Override endpoint/result tag via env: PORT=30002 TAG=newcfg ./bench-qwen-flash-next.sh
set -euo pipefail

BENCHY_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
RESULTS_DIR="${BENCHY_DIR}/results"
mkdir -p "${RESULTS_DIR}"

PORT=${PORT:-8035}
TAG=${TAG:-}
BASE_URL=${BASE_URL:-http://server60:${PORT}/v1}
MODEL=${MODEL:-qwen3.8-flash-next-ud-q4-k-xl}
SUFFIX=${TAG:+-${TAG}}

for C in 1 2; do
  echo "=== agentic-quick: ${MODEL} @ ${BASE_URL} concurrency ${C} ==="
  "${BENCHY_DIR}/agentic-quick.sh" \
    --base-url "${BASE_URL}" \
    --model "${MODEL}" \
    --concurrency "${C}" \
    --save-result "${RESULTS_DIR}/qwen-flash-next-quick${SUFFIX}-c${C}.json" \
    --format json
done
