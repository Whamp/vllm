#!/usr/bin/env python3
from __future__ import annotations

import argparse
import concurrent.futures
import json
import statistics
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any


def request_json(endpoint: str, path: str) -> dict[str, Any]:
    with urllib.request.urlopen(endpoint + path, timeout=60) as response:
        return json.load(response)


def streamed_decode(
    endpoint: str,
    model: str,
    phase: str,
    stream: int,
    output_tokens: int,
    barrier: threading.Barrier,
) -> dict[str, Any]:
    payload = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": (
                    f"TRACE-PHASE-{phase}-STREAM-{stream}. Write a detailed "
                    "technical essay about deterministic distributed recovery. "
                    "Continue until the token limit."
                ),
            }
        ],
        "temperature": 0.6,
        "top_p": 0.95,
        "top_k": 20,
        "max_tokens": output_tokens,
        "min_tokens": output_tokens,
        "ignore_eos": True,
        "stream": True,
        "stream_options": {"include_usage": True},
    }
    request = urllib.request.Request(
        endpoint + "/v1/chat/completions",
        data=json.dumps(payload).encode(),
        headers={
            "Content-Type": "application/json",
            "X-Request-Id": f"trace-{phase}-stream-{stream}",
        },
    )
    barrier.wait(timeout=30)
    wall_start_ns = time.time_ns()
    monotonic_start_ns = time.perf_counter_ns()
    first_delta_ns = None
    usage = None
    finish_reason = None
    with urllib.request.urlopen(request, timeout=1800) as response:
        for raw_line in response:
            line = raw_line.decode().strip()
            if not line.startswith("data: "):
                continue
            content = line[6:]
            if content == "[DONE]":
                break
            event = json.loads(content)
            if event.get("usage"):
                usage = event["usage"]
            for choice in event.get("choices", []):
                delta = choice.get("delta", {})
                if first_delta_ns is None and any(
                    delta.get(key)
                    for key in ("content", "reasoning", "reasoning_content")
                ):
                    first_delta_ns = time.perf_counter_ns()
                if choice.get("finish_reason") is not None:
                    finish_reason = choice["finish_reason"]
    monotonic_end_ns = time.perf_counter_ns()
    wall_end_ns = time.time_ns()
    if first_delta_ns is None or usage is None:
        raise RuntimeError(f"trace phase {phase} omitted timing or usage")
    completion_tokens = int(usage["completion_tokens"])
    if completion_tokens != output_tokens:
        raise RuntimeError(
            f"trace phase {phase} returned {completion_tokens}, "
            f"expected {output_tokens}"
        )
    decode_seconds = (monotonic_end_ns - first_delta_ns) / 1e9
    return {
        "stream": stream,
        "wall_start_ns": wall_start_ns,
        "wall_end_ns": wall_end_ns,
        "monotonic_start_ns": monotonic_start_ns,
        "first_delta_monotonic_ns": first_delta_ns,
        "monotonic_end_ns": monotonic_end_ns,
        "wall_seconds": (monotonic_end_ns - monotonic_start_ns) / 1e9,
        "ttft_seconds": (first_delta_ns - monotonic_start_ns) / 1e9,
        "decode_seconds": decode_seconds,
        "prompt_tokens": int(usage["prompt_tokens"]),
        "completion_tokens": completion_tokens,
        "decode_tokens_per_second": completion_tokens / decode_seconds,
        "finish_reason": finish_reason,
    }


def run_phase(
    endpoint: str,
    model: str,
    phase: str,
    concurrency: int,
    output_tokens: int,
) -> dict[str, Any]:
    phase_wall_start_ns = time.time_ns()
    phase_monotonic_start_ns = time.perf_counter_ns()
    barrier = threading.Barrier(concurrency)
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
        futures = [
            pool.submit(
                streamed_decode,
                endpoint,
                model,
                phase,
                stream,
                output_tokens,
                barrier,
            )
            for stream in range(concurrency)
        ]
        runs = [future.result() for future in futures]
    phase_monotonic_end_ns = time.perf_counter_ns()
    phase_wall_end_ns = time.time_ns()
    first_delta_ns = min(run["first_delta_monotonic_ns"] for run in runs)
    last_end_ns = max(run["monotonic_end_ns"] for run in runs)
    completion_tokens = sum(run["completion_tokens"] for run in runs)
    return {
        "phase": phase,
        "concurrency": concurrency,
        "requested_tokens_per_stream": output_tokens,
        "phase_wall_start_ns": phase_wall_start_ns,
        "phase_wall_end_ns": phase_wall_end_ns,
        "phase_monotonic_start_ns": phase_monotonic_start_ns,
        "phase_monotonic_end_ns": phase_monotonic_end_ns,
        "runs": runs,
        "aggregate_decode_tokens_per_second": completion_tokens
        / ((last_end_ns - first_delta_ns) / 1e9),
        "aggregate_wall_tokens_per_second": completion_tokens
        / ((last_end_ns - phase_monotonic_start_ns) / 1e9),
        "mean_per_stream_decode_tokens_per_second": statistics.mean(
            run["decode_tokens_per_second"] for run in runs
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--endpoint", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--warmup-only", action="store_true")
    args = parser.parse_args()

    endpoint = args.endpoint.rstrip("/")
    models = request_json(endpoint, "/v1/models")
    if [record["id"] for record in models["data"]] != [args.model]:
        raise RuntimeError(f"trace model identity mismatch: {models}")

    if args.warmup_only:
        phases = [run_phase(endpoint, args.model, "warmup-c1", 1, 128)]
    else:
        phases = []
        for phase, concurrency in (("c1", 1), ("c2", 2)):
            phases.append(run_phase(endpoint, args.model, phase, concurrency, 256))
            if phase != "c2":
                time.sleep(5)

    result = {
        "schema_version": 1,
        "model": args.model,
        "endpoint": endpoint,
        "warmup_only": args.warmup_only,
        "process_wall_time_ns": time.time_ns(),
        "process_monotonic_time_ns": time.perf_counter_ns(),
        "phases": phases,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    temporary.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    temporary.replace(args.output)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
