#!/usr/bin/env bash
set -euo pipefail
arm=${1:?arm required}
case "$arm" in control|candidate) ;; *) exit 64 ;; esac
root=/home/will/build/qwen38-shared-expert-overlap/post-bios-x8-20260831/trace
compose="$root/$arm.yml"
out="$root/$arm"
container="qwen38-shared-expert-trace-$arm"
project="$container"
session="qwen38sharedexpert$arm"
nsys=/opt/nsys/bin/nsys
model=qwen3.8-flash-next-intel-autoround-w4a16
mkdir -p "$out"
cleanup() {
  rc=$?
  trap - EXIT INT TERM
  sudo -n sysctl -q -w vm.overcommit_memory=0 >/dev/null || true
  if [[ "$(docker inspect "$container" --format "{{.State.Running}}" 2>/dev/null || true)" == true ]]; then
    docker exec "$container" "$nsys" stop --session="$session" >"$out/cleanup-nsys-stop.log" 2>&1 || true
    docker logs "$container" >"$out/container.log" 2>&1 || true
  fi
  docker rm -f "$container" >/dev/null 2>&1 || true
  exit "$rc"
}
trap cleanup EXIT
trap "exit 130" INT TERM
systemctl --user is-active --quiet qwen38-shared-expert-postbios-restore.timer
[[ -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader | sed "/^$/d")" ]]
[[ "$(swapon --show --noheadings | wc -l)" == 0 ]]
sudo -n sysctl -q -w vm.overcommit_memory=1 >/dev/null
rm -f "$out/$arm.nsys-rep" "$out/$arm.sqlite" "$out/$arm.qdstrm"
docker compose -p "$project" --profile qwen38-flash-next -f "$compose" up -d
ready=0
for poll in $(seq 1 240); do
  running=$(docker inspect "$container" --format "{{.State.Running}}" 2>/dev/null || true)
  health=$(docker inspect "$container" --format "{{if .State.Health}}{{.State.Health.Status}}{{end}}" 2>/dev/null || true)
  if [[ "$running" == true && "$health" == healthy ]] && curl -fsS http://127.0.0.1:30014/health >/dev/null 2>&1; then ready=1; break; fi
  if [[ "$running" != true ]]; then docker logs "$container" >"$out/startup-failure.log" 2>&1 || true; exit 1; fi
  if (( poll % 20 == 0 )); then printf "TRACE_%s_STARTUP_POLL=%s HEALTH=%s\n" "$arm" "$poll" "$health"; fi
  sleep 15
done
[[ "$ready" == 1 ]]
sudo -n sysctl -q -w vm.overcommit_memory=0 >/dev/null
docker logs "$container" >"$out/pre-trace-server.log" 2>&1
docker inspect "$container" >"$out/container-inspect.json"
curl -fsS http://127.0.0.1:30014/v1/models >"$out/models.json"
python3 - "$out/models.json" <<"PY"
import json,sys
r=json.load(open(sys.argv[1]))["data"][0]
assert r["id"]=="qwen3.8-flash-next-intel-autoround-w4a16"
assert r["max_model_len"]==262144
PY
grep "GPU KV cache size:" "$out/pre-trace-server.log" | tail -1 >"$out/kv-capacity.txt"
docker exec "$container" "$nsys" sessions list >"$out/sessions-before.txt"
grep -q "$session" "$out/sessions-before.txt"
python3 "$root/trace_workload.py" --endpoint http://127.0.0.1:30014 --model "$model" --output "$out/warmup.json" --warmup-only >"$out/warmup.stdout"
docker exec "$container" "$nsys" start --session="$session" --sample=none --cpuctxsw=none --output="/trace/$arm" --force-overwrite=true --export=sqlite >"$out/nsys-start.stdout" 2>"$out/nsys-start.stderr"
sleep 1
python3 "$root/trace_workload.py" --endpoint http://127.0.0.1:30014 --model "$model" --output "$out/workload.json" >"$out/workload.stdout"
docker exec "$container" "$nsys" stop --session="$session" >"$out/nsys-stop.stdout" 2>"$out/nsys-stop.stderr"
[[ -s "$out/$arm.nsys-rep" ]]
[[ -s "$out/$arm.sqlite" ]]
[[ "$(stat -c %s "$out/$arm.nsys-rep")" -gt 1000000 ]]
[[ "$(stat -c %s "$out/$arm.sqlite")" -gt 1000000 ]]
curl -fsS http://127.0.0.1:30014/health >"$out/post-trace-health.txt"
docker logs "$container" >"$out/post-trace-server.log" 2>&1
nvidia-smi --query-gpu=index,memory.used,memory.free,power.draw,clocks.current.graphics,temperature.gpu --format=csv,noheader,nounits >"$out/post-trace-nvml.csv"
sha256sum "$out/$arm.nsys-rep" "$out/$arm.sqlite" >"$out/trace.sha256"
docker stop -t 120 "$container" >/dev/null
docker rm -f "$container" >/dev/null 2>&1 || true
for _ in $(seq 1 60); do [[ -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader | sed "/^$/d")" ]] && break; sleep 2; done
[[ -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader | sed "/^$/d")" ]]
printf "TRACE_%s_COMPLETE=1\n" "$arm"
trap - EXIT INT TERM
