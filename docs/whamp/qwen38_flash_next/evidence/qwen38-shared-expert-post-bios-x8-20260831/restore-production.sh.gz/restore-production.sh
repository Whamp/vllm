#!/usr/bin/env bash
set -euo pipefail
runtime=/home/will/inference/runtime/qwen38-shared-expert-overlap/0a5e08118
"$runtime/scripts/qwen38_verify_shared_expert_rollback.sh" >/dev/null
sudo -n sysctl -q -w vm.overcommit_memory=0 >/dev/null || true
docker rm -f \
  qwen38-shared-expert-control \
  qwen38-shared-expert-candidate \
  qwen38-shared-expert-trace-control \
  qwen38-shared-expert-trace-candidate \
  >/dev/null 2>&1 || true
exec /usr/bin/bash /home/will/inference/runtime/qwen38-qsa-fp8-candidate/restore-fp8.sh
