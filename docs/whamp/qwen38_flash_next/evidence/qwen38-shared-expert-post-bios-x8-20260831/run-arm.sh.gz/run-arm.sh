#!/usr/bin/env bash
set -euo pipefail
arm=${1:?arm name required}
variant=${2:?control or candidate required}
case "$variant" in control|candidate) ;; *) exit 64 ;; esac
root=/home/will/build/qwen38-shared-expert-overlap/post-bios-x8-20260831
compose="$root/$variant.yml"
out="$root/$arm"
container="qwen38-shared-expert-$variant"
project="qwen38-shared-expert-postbios-$arm"
model=qwen3.8-flash-next-intel-autoround-w4a16
mkdir -p "$out"
cleanup() {
  rc=$?
  trap - EXIT INT TERM
  sudo -n sysctl -q -w vm.overcommit_memory=0 >/dev/null || true
  if docker inspect "$container" >/dev/null 2>&1; then
    docker logs "$container" >"$out/container-final.log" 2>&1 || true
    docker rm -f "$container" >/dev/null 2>&1 || true
  fi
  exit "$rc"
}
trap cleanup EXIT
trap "exit 130" INT TERM
systemctl --user is-active --quiet qwen38-shared-expert-postbios-restore.timer
systemctl is-active --quiet gpu-power-limit.service
[[ "$(swapon --show --noheadings | wc -l)" == 0 ]]
[[ -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader | sed "/^$/d")" ]]
rm -f "$out/benchmark.json" "$out/benchmark.stdout.json"
sudo -n sysctl -q -w vm.overcommit_memory=1 >/dev/null
docker compose -p "$project" --profile qwen38-flash-next -f "$compose" up -d
ready=0
for poll in $(seq 1 240); do
  running=$(docker inspect "$container" --format "{{.State.Running}}" 2>/dev/null || true)
  health=$(docker inspect "$container" --format "{{if .State.Health}}{{.State.Health.Status}}{{end}}" 2>/dev/null || true)
  if [[ "$running" == true && "$health" == healthy ]] && curl -fsS http://127.0.0.1:30003/health >/dev/null 2>&1; then ready=1; break; fi
  if [[ "$running" != true ]]; then docker logs "$container" >"$out/startup-failure.log" 2>&1 || true; exit 1; fi
  if (( poll % 20 == 0 )); then printf "ARM=%s STARTUP_POLL=%s HEALTH=%s\n" "$arm" "$poll" "$health"; fi
  sleep 15
done
[[ "$ready" == 1 ]]
sudo -n sysctl -q -w vm.overcommit_memory=0 >/dev/null
[[ "$(docker inspect "$container" --format "{{.Image}}")" == sha256:39de8fdfb787592cf06819268a817c8a4087d84658e2300d7adb5ad136b59bb3 ]]
[[ "$(docker inspect "$container" --format "{{.RestartCount}}")" == 0 ]]
[[ "$(docker inspect "$container" --format "{{.HostConfig.RestartPolicy.Name}}")" == no ]]
docker logs "$container" >"$out/startup.log" 2>&1
docker inspect "$container" >"$out/container-inspect.json"
curl -fsS http://127.0.0.1:30003/v1/models >"$out/models.json"
python3 - "$out/models.json" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]))["data"]
assert len(r)==1
assert r[0]["id"]=="qwen3.8-flash-next-intel-autoround-w4a16"
assert r[0]["max_model_len"]==262144
PY
for dev in 0000:08:00.0 0000:09:00.0 0000:41:00.0 0000:42:00.0; do
  printf "%s width=%s speed=%s\n" "$dev" "$(cat /sys/bus/pci/devices/$dev/current_link_width)" "$(cat /sys/bus/pci/devices/$dev/current_link_speed)"
done >"$out/pcie-under-load.txt"
nvidia-smi --query-gpu=index,pci.bus_id,memory.used,memory.free,power.draw,clocks.current.graphics,temperature.gpu --format=csv,noheader,nounits >"$out/pre-benchmark-nvml.csv"
python3 "$root/benchmark-concurrencies.py" \
  --endpoint http://127.0.0.1:30003 \
  --model "$model" \
  --label "$arm" \
  --output "$out/benchmark.json" \
  --decode-tokens 256 \
  --concurrency 1 --concurrency 2 --concurrency 4 \
  >"$out/benchmark.stdout.json"
nvidia-smi --query-gpu=index,pci.bus_id,memory.used,memory.free,power.draw,clocks.current.graphics,temperature.gpu --format=csv,noheader,nounits >"$out/post-benchmark-nvml.csv"
worker_swap=0
for pid in $(docker top "$container" -o pid | tail -n +2); do
  worker_swap=$((worker_swap+$(awk "/^VmSwap:/{print \$2+0}" /proc/$pid/status)))
done
printf "WORKER_SWAP_KB=%s\n" "$worker_swap" >"$out/health.txt"
[[ "$worker_swap" == 0 ]]
if grep -E "CUDA out of memory|EngineCore failed|allocator.*failed|Worker.*died" "$out/startup.log" >"$out/failure-signatures.txt"; then exit 1; else : >"$out/failure-signatures.txt"; fi
docker stop -t 120 "$container" >/dev/null
docker rm -f "$container" >/dev/null 2>&1 || true
for _ in $(seq 1 120); do
  [[ -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader | sed "/^$/d")" ]] && break
  sleep 2
done
[[ -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader | sed "/^$/d")" ]]
sha256sum "$out"/* >"$out/SHA256SUMS"
printf "ARM_COMPLETE=%s VARIANT=%s\n" "$arm" "$variant"
trap - EXIT INT TERM
