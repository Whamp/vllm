#!/usr/bin/env bash
set -euo pipefail
runtime=/home/will/inference/runtime/qwen38-qsa-fp8-candidate
compose="$runtime/production.yml"
backup="$runtime/production-095-before-098.yml"
container=qwen38-qsa-fp8-candidate
cp -f "$backup" "$compose"
sudo swapoff -a
sudo sysctl -q -w vm.overcommit_memory=1
docker compose -p qwen38-qsa-fp8-candidate --profile qwen38-flash-next -f "$compose" up -d --force-recreate
for poll in $(seq 1 240); do
  if curl -fsS http://127.0.0.1:30002/health >/dev/null 2>&1; then break; fi
  [[ "$(docker inspect -f '{{.State.Running}}' "$container" 2>/dev/null || true)" == true ]]
  if ((poll == 240)); then docker logs --tail 1000 "$container" >&2; exit 1; fi
  sleep 15
done
sudo sysctl -q -w vm.overcommit_memory=0
[[ "$(docker inspect -f '{{.State.Health.Status}}' "$container")" == healthy ]]
[[ "$(docker inspect -f '{{.RestartCount}}' "$container")" == 0 ]]
[[ "$(docker inspect -f '{{.HostConfig.RestartPolicy.Name}}' "$container")" == unless-stopped ]]
test -z "$(swapon --show --noheadings)"
echo "Qwen3.8 0.95 rollback restored healthy."
