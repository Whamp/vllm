#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0

import json
import time
import urllib.request
from pathlib import Path

ENDPOINT = "http://127.0.0.1:30003"
MODEL = "qwen3.8-flash-next-intel-autoround-w4a16"
OUTPUT = Path(
    "/home/will/inference/runtime/qwen38-ple-bf16-ssd/"
    "9a2bdd3e39b3ad692f4b4d3c9a5f9d2bde91a3a4/candidate-extra-functional.json"
)


def request_json(path: str, payload: dict | None = None, timeout: int = 1800) -> dict:
    request = urllib.request.Request(
        ENDPOINT + path,
        data=None if payload is None else json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def prefix_metrics() -> dict[str, float]:
    with urllib.request.urlopen(ENDPOINT + "/metrics", timeout=60) as response:
        lines = response.read().decode().splitlines()
    result = {}
    for metric in ("vllm:prefix_cache_queries_total", "vllm:prefix_cache_hits_total"):
        values = [
            float(line.rsplit(" ", 1)[1])
            for line in lines
            if line.startswith(metric + "{")
        ]
        if len(values) != 1:
            raise RuntimeError(f"expected one {metric} series, got {values}")
        result[metric] = values[0]
    return result


arithmetic = request_json(
    "/v1/chat/completions",
    {
        "model": MODEL,
        "messages": [
            {"role": "user", "content": "What is 17 * 23? Reply with only the number."}
        ],
        "temperature": 0,
        "max_tokens": 64,
    },
)
arithmetic_message = arithmetic["choices"][0]["message"]
arithmetic_text = " ".join(
    str(arithmetic_message.get(key) or "")
    for key in ("content", "reasoning", "reasoning_content")
)
if "391" not in arithmetic_text:
    raise RuntimeError(f"arithmetic probe failed: {arithmetic}")

reasoning = request_json(
    "/v1/chat/completions",
    {
        "model": MODEL,
        "messages": [
            {
                "role": "user",
                "content": (
                    "A box has 29 rows with 37 bolts in each row. Compute the total, "
                    "check it a second way, and state the final number."
                ),
            }
        ],
        "temperature": 0,
        "reasoning_effort": "xhigh",
        "max_tokens": 512,
    },
)
reasoning_message = reasoning["choices"][0]["message"]
reasoning_text = " ".join(
    str(reasoning_message.get(key) or "")
    for key in ("content", "reasoning", "reasoning_content")
)
if "1073" not in reasoning_text:
    raise RuntimeError(f"reasoning probe failed: {reasoning}")
if not (
    reasoning_message.get("reasoning")
    or reasoning_message.get("reasoning_content")
):
    raise RuntimeError(f"reasoning trace was absent: {reasoning}")

prefix = "\n".join(
    f"Shared prefix row {index}: cache identity is stable and deterministic."
    for index in range(5000)
)
before = prefix_metrics()
results = []
for suffix in ("FIRST", "SECOND"):
    start = time.perf_counter()
    response = request_json(
        "/v1/chat/completions",
        {
            "model": MODEL,
            "messages": [
                {
                    "role": "user",
                    "content": prefix + f"\nReply with exactly {suffix}",
                }
            ],
            "temperature": 0,
            "max_tokens": 64,
        },
    )
    elapsed = time.perf_counter() - start
    content = (response["choices"][0]["message"].get("content") or "").strip()
    if suffix not in content:
        raise RuntimeError(f"prefix response failed for {suffix}: {response}")
    results.append({"suffix": suffix, "elapsed_seconds": elapsed, "response": response})
    if suffix == "FIRST":
        middle = prefix_metrics()
after = prefix_metrics()
first_queries = middle["vllm:prefix_cache_queries_total"] - before[
    "vllm:prefix_cache_queries_total"
]
second_queries = after["vllm:prefix_cache_queries_total"] - middle[
    "vllm:prefix_cache_queries_total"
]
second_hits = after["vllm:prefix_cache_hits_total"] - middle[
    "vllm:prefix_cache_hits_total"
]
if first_queries <= 0 or second_queries <= 0 or second_hits <= 0:
    raise RuntimeError(
        f"prefix cache did not record repeated-prefix hits: "
        f"first_queries={first_queries}, second_queries={second_queries}, "
        f"second_hits={second_hits}"
    )

result = {
    "arithmetic": arithmetic,
    "reasoning": reasoning,
    "prefix_cache": {
        "before": before,
        "middle": middle,
        "after": after,
        "first_query_delta": first_queries,
        "second_query_delta": second_queries,
        "second_hit_delta": second_hits,
        "second_hit_ratio": second_hits / second_queries,
        "runs": results,
    },
}
OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(
    json.dumps(
        {
            "arithmetic": "passed",
            "reasoning": "passed",
            "prefix_cache_second_hit_ratio": second_hits / second_queries,
        },
        indent=2,
        sort_keys=True,
    )
)
