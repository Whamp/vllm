#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0

import argparse
import json
import os
import subprocess
import time
from pathlib import Path


def read_key_values(path: Path) -> dict[str, int]:
    result = {}
    for line in path.read_text().splitlines():
        key, value = line.split(":", 1)
        result[key] = int(value.strip())
    return result


def find_ple_worker(container: str) -> tuple[int, str]:
    output = subprocess.check_output(
        ["docker", "top", container, "-eo", "pid,ppid,comm,args"],
        text=True,
    )
    matches = []
    for line in output.splitlines()[1:]:
        if "multiprocessing.spawn import spawn_main" in line:
            matches.append((int(line.split()[0]), line))
    if len(matches) != 1:
        raise RuntimeError(f"expected one spawned PLE worker, got {matches}")
    return matches[0]


def mapping_stats(pid: int, expected_fragment: str) -> dict[str, int]:
    totals = {"mapping_count": 0, "size_kib": 0, "rss_kib": 0, "referenced_kib": 0}
    selected = False
    for line in Path(f"/proc/{pid}/smaps").read_text().splitlines():
        if line and line[0].isdigit() and "-" in line.split()[0]:
            selected = expected_fragment in line
            if selected:
                totals["mapping_count"] += 1
            continue
        if not selected:
            continue
        if line.startswith("Size:"):
            totals["size_kib"] += int(line.split()[1])
        elif line.startswith("Rss:"):
            totals["rss_kib"] += int(line.split()[1])
        elif line.startswith("Referenced:"):
            totals["referenced_kib"] += int(line.split()[1])
    return totals


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--container", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--ple-fragment", required=True)
    args = parser.parse_args()

    pid, process_line = find_ple_worker(args.container)
    fields = Path(f"/proc/{pid}/stat").read_text().split()
    clock_ticks = os.sysconf("SC_CLK_TCK")
    block_fields = [
        int(value) for value in Path("/sys/block/nvme0n1/stat").read_text().split()
    ]
    result = {
        "schema_version": 1,
        "timestamp_monotonic_ns": time.monotonic_ns(),
        "timestamp_unix_ns": time.time_ns(),
        "container": args.container,
        "ple_worker_pid": pid,
        "ple_worker_process": process_line,
        "ple_worker": {
            "minor_faults": int(fields[9]),
            "major_faults": int(fields[11]),
            "user_cpu_seconds": int(fields[13]) / clock_ticks,
            "system_cpu_seconds": int(fields[14]) / clock_ticks,
            "io": read_key_values(Path(f"/proc/{pid}/io")),
            "mapping": mapping_stats(pid, args.ple_fragment),
        },
        "nvme0n1": {
            "reads_completed": block_fields[0],
            "reads_merged": block_fields[1],
            "sectors_read": block_fields[2],
            "read_bytes": block_fields[2] * 512,
            "read_time_ms": block_fields[3],
            "writes_completed": block_fields[4],
            "sectors_written": block_fields[6],
            "write_bytes": block_fields[6] * 512,
            "write_time_ms": block_fields[7],
        },
        "host": {
            "vm_overcommit_memory": int(
                Path("/proc/sys/vm/overcommit_memory").read_text()
            ),
            "swap_devices": subprocess.check_output(
                ["swapon", "--show", "--noheadings"], text=True
            ).splitlines(),
        },
        "nvidia_smi": subprocess.check_output(
            [
                "nvidia-smi",
                (
                    "--query-gpu=index,power.draw,power.limit,clocks.current.graphics,"
                    "memory.used,memory.free,temperature.gpu"
                ),
                "--format=csv,noheader,nounits",
            ],
            text=True,
        ).splitlines(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    temporary.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    temporary.replace(args.output)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
