## Quality bench, thinking mixed(pack-defaults), benchlocal-cli v0.9.10, repeat = 1

Pack | Pass / Total | Score | Std | CV | p50 latency | p95 latency | Status
---|---:|---:|---:|---:|---:|---:|---
toolcall-15 (v1.0.1) | 15 / 15 | 100% | — | — | 1.23s | 2.44s | ok
instructfollow-15 (v1.0.0) | 15 / 15 | 100% | — | — | 4.58s | 34.93s | ok

TOTAL | 30 / 30 | 100% |  |  |  |  |

Equivalent to: 150/150

<details>
<summary>Raw data</summary>

```
=== benchlocal-cli --quick  (endpoint: http://127.0.0.1:30003, model: qwen3.8-flash-next-intel-autoround-w4a16, thinking=mixed(pack-defaults), 2026-08-31T18:08:54.239431Z) ===

  [1/15] TC-01 ✓ passed pass@1 (2.3s)
  [2/15] TC-02 ✓ passed pass@1 (1.4s)
  [3/15] TC-03 ✓ passed pass@1 (1.2s)
  [4/15] TC-04 ✓ passed pass@1 (1.0s)
  [5/15] TC-05 ✓ passed pass@1 (2.4s)
  [6/15] TC-06 ✓ passed pass@1 (2.0s)
  [7/15] TC-07 ✓ passed pass@1 (1.6s)
  [8/15] TC-08 ✓ passed pass@1 (0.9s)
  [9/15] TC-09 ✓ passed pass@1 (1.3s)
  [10/15] TC-10 ✓ passed pass@1 (0.5s)
  [11/15] TC-11 ✓ passed pass@1 (0.8s)
  [12/15] TC-12 ✓ passed pass@1 (3.5s)
  [13/15] TC-13 ✓ passed pass@1 (1.0s)
  [14/15] TC-14 ✓ passed pass@1 (0.9s)
  [15/15] TC-15 ✓ passed pass@1 (0.9s)
toolcall-15 (v1.0.1) | 15 / 15 | 100% | 1.23s | ok
  [1/15] IF-01 ✓ passed pass@1 (10.1s)
  [2/15] IF-02 ✓ passed pass@1 (3.8s)
  [3/15] IF-03 ✓ passed pass@1 (3.7s)
  [4/15] IF-04 ✓ passed pass@1 (3.5s)
  [5/15] IF-05 ✓ passed pass@1 (5.0s)
  [6/15] IF-06 ✓ passed pass@1 (2.8s)
  [7/15] IF-07 ✓ passed pass@1 (9.2s)
  [8/15] IF-08 ✓ passed pass@1 (4.1s)
  [9/15] IF-09 ✓ passed pass@1 (4.6s)
  [10/15] IF-10 ✓ passed pass@1 (34.9s)
  [11/15] IF-11 ✓ passed pass@1 (76.5s)
  [12/15] IF-12 ✓ passed pass@1 (10.1s)
  [13/15] IF-13 ✓ passed pass@1 (1.3s)
  [14/15] IF-14 ✓ passed pass@1 (4.0s)
  [15/15] IF-15 ✓ passed pass@1 (5.0s)
instructfollow-15 (v1.0.0) | 15 / 15 | 100% | 4.58s | ok

Pack | Pass / Total | Score | Δ (vs prev) | p50 latency | p95 latency | Status
---|---:|---:|---|---:|---:|---
toolcall-15 (v1.0.1) | 15 / 15 | 100% | +1 fix | 1.23s | 2.44s | ok
instructfollow-15 (v1.0.0) | 15 / 15 | 100% | +1 fix | 4.58s | 34.93s | ok

TOTAL | 30 / 30 | 100% | +2 fixes |  |  |

Completion and extraction diagnostics:

Pack | finish_reason=length | extraction_method | extraction_issue | response_field_used
---|---:|---|---|---
toolcall-15 | 0 / 15 (0.0%) | — | — | message.content=6
instructfollow-15 | 0 / 15 (0.0%) | — | — | message.content=15

Warnings:
- timeout scaling active: measured_decode_tps=59.9, reference_tps=100.0, scale=1.67, token-budget-multiplier=16384/1024=16.00
```

</details>
