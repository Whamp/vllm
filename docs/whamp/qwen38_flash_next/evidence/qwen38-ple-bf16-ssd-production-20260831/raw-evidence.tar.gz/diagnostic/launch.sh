#!/usr/bin/env bash
set -euo pipefail
root=/home/will/inference/runtime/qwen38-ple-bf16-ssd
run=/home/will/inference/runtime/qwen38-ple-bf16-ssd/9a2bdd3e39b3ad692f4b4d3c9a5f9d2bde91a3a4
candidate=qwen38-ple-bf16-ssd-candidate
watchdog=qwen38-ple-bf16-ssd-restore
control_manifest_sha=3da9bdd047b1985447ce9ee5ebc45086b7301ccf4b6baf9eed30af5feb5a3775
ready=0
cleanup_on_failure() {
  sudo -n sysctl -q -w vm.overcommit_memory=0 >/dev/null || true
  if ((ready == 0)); then
    "$root/restore-production.sh" || true
  fi
}
trap cleanup_on_failure EXIT
"$root/verify.sh"
(
  cd "$run/diagnostic"
  sha256sum -c SHA256SUMS
)
[[ "$(docker inspect "$candidate" --format '{{.State.Health.Status}}')" == healthy ]]
restore_command="set -euo pipefail; cd '$root'; test \"\$(sha256sum CONTROL-SHA256SUMS | cut -d' ' -f1)\" = '$control_manifest_sha'; sha256sum -c CONTROL-SHA256SUMS; exec ./restore-production.sh"
systemctl --user stop "$watchdog.timer" "$watchdog.service" >/dev/null 2>&1 || true
systemctl --user reset-failed "$watchdog.service" >/dev/null 2>&1 || true
systemd-run --user --unit="$watchdog" --on-active=2h \
  --property=Type=oneshot --property=WorkingDirectory="$root" \
  /bin/bash -c "$restore_command" >/dev/null
systemctl --user is-active --quiet "$watchdog.timer"
docker rm -f "$candidate" >/dev/null 2>&1 || true
sudo -n swapoff -a
sudo -n sysctl -q -w vm.overcommit_memory=1 >/dev/null
docker compose -p qwen38-ple-bf16-ssd --profile qwen38-bf16-ple \
  -f "$run/diagnostic/diagnostic.yml" up -d
for poll in $(seq 1 240); do
  if curl -fsS http://127.0.0.1:30003/health >/dev/null 2>&1; then
    break
  fi
  [[ "$(docker inspect "$candidate" --format '{{.State.Running}}' 2>/dev/null || true)" == true ]]
  if ((poll == 240)); then
    docker logs --tail 1500 "$candidate" >&2
    exit 1
  fi
  sleep 15
done
sudo -n sysctl -q -w vm.overcommit_memory=0 >/dev/null
for poll in $(seq 1 30); do
  health=$(docker inspect "$candidate" --format '{{.State.Health.Status}}')
  [[ "$health" != unhealthy ]]
  if [[ "$health" == healthy ]]; then
    break
  fi
  if ((poll == 30)); then
    exit 1
  fi
  sleep 10
done
[[ "$(docker inspect "$candidate" --format '{{.State.Health.Status}}')" == healthy ]]
[[ "$(docker inspect "$candidate" --format '{{.RestartCount}}')" == 0 ]]
[[ "$(docker inspect "$candidate" --format '{{.HostConfig.RestartPolicy.Name}}')" == no ]]
[[ "$(sysctl -n vm.overcommit_memory)" == 0 ]]
[[ "$(swapon --show --noheadings | wc -l)" == 0 ]]
docker inspect "$candidate" --format '{{range .Config.Env}}{{println .}}{{end}}' | grep -Fqx 'VLLM_PLE_TIMING_LOG_EVERY=32'
ready=1
trap - EXIT
echo DIAGNOSTIC_CANDIDATE_READY=1
